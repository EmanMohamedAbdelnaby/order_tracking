class AppRoutes {
  static const String splashScreen = '/splashScreen';
  static const String loginScreen = '/loginScreen';
  static const String registerScreen = '/registerScreen';

  static const String mainScreen = '/mainScreen';

  static const String productScreen = '/productScreen';
  static const String addressScreen = '/addressScreen';
}
