class AppConstants {
  static const String newsApiKey = "0b5c8b08d3574e0594e70a2112049440";
  static String lang = "ar";
}
