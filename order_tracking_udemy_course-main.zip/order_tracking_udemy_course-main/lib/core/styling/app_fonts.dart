class AppFonts {
  static String mainFontName = "Urbanist";
}
