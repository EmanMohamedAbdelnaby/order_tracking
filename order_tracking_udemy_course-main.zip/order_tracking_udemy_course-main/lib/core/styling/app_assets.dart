class AppAssets {
  static const iconsPath = 'assets/icons/';

  static const imagePath = 'assets/images/';

  static const String logo = '${iconsPath}logo.png';
  static const String order = '${iconsPath}order.png';
  static const String truck = '${iconsPath}truck.png';
}
